function CheckData() 
{
var ans;
ans = confirm("Вы уверены, что хотите отправить введенные данные ?");
if (ans) submit(); 
}
